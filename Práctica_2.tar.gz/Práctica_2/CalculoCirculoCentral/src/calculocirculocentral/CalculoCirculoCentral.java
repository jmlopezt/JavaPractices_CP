/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package calculocirculocentral;
/**
 *
 * @author juanma
 */
public class CalculoCirculoCentral {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        double Radio_final;
        
        Circulo circulo1 = new Circulo();
        Circulo circulo2 = new Circulo();
        Circulo CirculoCentral=new Circulo();
               
        circulo1.LeeCirculo();
        circulo2.LeeCirculo();
           
        /* Obtiene el centro del nuevo circulo como el punto medio entre las coordenada x e y de cada uno*/
        CirculoCentral.centro=circulo1.centro.PuntoMedio(circulo2.centro.ObtieneCoordenada_x(), circulo2.centro.ObtieneCoordenada_y());
        /* Obtiene el radio final como la mitad de la distancia euclidea entre los centros de dichos circulos*/
        Radio_final=(circulo1.centro.CalcDistEuclid(circulo2.centro.ObtieneCoordenada_x(), circulo2.centro.ObtieneCoordenada_y()))/2;
        
        
        CirculoCentral.RadioCirculo(Radio_final); /* Obtiene el nuevo radio */
        System.out.println("\nEste es el círculo central:   ");
        CirculoCentral.EscribeCirculo();/* Escribe la definición del circulo por pantalla*/
    }
    
}
